
library( data.table)
library( ggplot2)
library( DT)
library( fasttime)
# Create artificial rates
## Point in time rates
m <- list()

# Create Blank theme for plots
blank_theme <- function( base_size = 12, base_family = ""){
  theme_minimal( base_size= base_size, base_family= base_family) +
    theme( axis.text.x= element_blank(), 
           axis.title.x= element_blank(), 
           axis.text.y= element_blank(), 
           axis.title.y= element_blank(), 
           legend.position= 'None',
           axis.ticks.x= element_blank(), 
           axis.ticks.y= element_blank(), 
           axis.ticks.length = unit( 0, "lines"),
           panel.grid.major.x = element_blank(),
           panel.grid.minor.x = element_blank(),
           panel.grid.major.y = element_blank(),
           panel.grid.minor.y = element_blank(),
           panel.margin.x = unit( 0.1, "lines"),
           panel.margin.y = unit( 0.2, "lines"),
           panel.background= element_rect(fill= NA, colour= NA),
           plot.background= element_rect(fill= NA, #rgb( 250, 250, 250, maxColorValue= 255), 
                                         colour= NA),
           plot.title = element_text(size = rel(1)),
           strip.text = element_blank(),
           strip.background= element_rect(fill= NA, colour= NA))
}

# Colour palette
m$p$cl$bl1 <- rgb( red= 0, green= 122, blue= 194, maxColorValue= 255)
m$p$cl$bl2 <- rgb( red= 0, green= 51, blue= 102, maxColorValue= 255)
m$p$cl$rd <- rgb( red= 109, green= 21, blue= 53, maxColorValue= 255)
m$p$cl$grn1 <- rgb( red= 2, green= 105, blue= 55, maxColorValue= 255)
m$p$cl$grn2 <- rgb( red= 121, green= 153, blue= 0, maxColorValue= 255)
m$p$cl$gry1 <- rgb( red= 182, green= 182, blue= 182, maxColorValue= 255)
m$p$cl$gry2 <- rgb( red= 100, green= 101, blue= 105, maxColorValue= 255)
m$p$fg_nbr <- 0


# Define currency pairs
m$p$ccys <- c( "EURUSD", "USDJPY", "GBPUSD", "USDCHF", "USDCAD", "AUDUSD")
# ...and timestamps at five minute intervals from beginning of 2012 till now
m$p$tms <- seq.POSIXt( from= as.POSIXct( '2012-01-01'), to= Sys.time(), by= 60*5 )
m$p$cpty <- c( "Citibank", "JP Morgan", "Deutsche Bank", "Barclays", "Morgan Stanley")
m$p$vnu <- c( "Phone", "FXAll", "Lava FX")

# Create artificial rates
m$i$rts <- data.table( 
  ccy= factor( rep( m$p$ccys, each= length( m$p$tms))), 
  tms= rep( m$p$tms, times= length( m$p$ccys)), 
  rt_1= rnorm( n= length( m$p$ccys) * length( m$p$tms), mean= 0, sd= 0.01),
  rt_2= rnorm( n= length( m$p$ccys) * length( m$p$tms), mean= 0, sd= 0.001))

# rate 1 is a random walk i.e. the sum of normal errors
m$i$rts[ , rt_1:= cumprod( 1+ rt_1), ccy]
# rate 2 is rate 1 + random noise at each point
m$i$rts[ , rt_2:= rt_1 + rt_2, ccy]

# Set the key: currency then timestamp
setkey( m$i$rts, ccy, tms)

# Create n artificial trades
m$p$n <- 10000

m$i$trds <- data.table(
  tms= as.POSIXct( runif( n= m$p$n, min= m$p$tms[ 1], max= m$p$tms[ length( m$p$tms)]), 
                        origin= "1970-01-01"),
  ccy= sample( x= m$p$ccy, size= m$p$n, 
               prob= c( 10, 6, 4, 3, 1, 1), replace= TRUE),
  drctn= sample( x= factor( c( "buy", "sell")), size= m$p$n, replace= TRUE),
  cpty= sample( x= m$p$cpty, size= m$p$n, replace= TRUE),
  cst= 5 + rexp( n= m$p$n, rate= 0.1),
  sz= sample( x= c( 1e5, 5e5, 1e6, 2e6, 5e6, 1e7, 1e8), size= m$p$n, 
              prob= c( 1, 2, 20, 3, 4, 3, 2), replace= TRUE))
  
setkey( m$i$trds, ccy, tms)

# Create rates on the trades = the artificial rate + cost
m$x$trds <- m$i$rts[ m$i$trds, roll= TRUE][ 
  , .( tms, ccy, drctn, cpty, 
       rt= rt_1 + ifelse( drctn== 'buy', -1, +1) * cst, 
       sz) ]
setkey( m$i$trds, ccy, tms)

m$x$rts <- m$x$rts

#--------------------
# Read in real rates and trades

setwd( 'C:\\stuff2\\Dropbox\\Public\\work\\doc\\asif\\TCA\\Shiny_V2')
m$i$rts <- rbindlist( idcol= "ccy",
  lapply( FUN= fread, stringsAsFactors= TRUE,
          X= c( `AUD/USD`= "AUDUSD.csv", `EUR/GBP`= "EURGBP.csv", 
                            `EUR/USD`= "EURUSD.csv", `GBP/USD`= "GBPUSD.csv",
                            `NZD/USD`= "NZDUSD.csv", `USD/CAD`= "USDCAD.csv", 
                            `USD/CHF`= "USDCHF.csv", `USD/JPY`= "USDJPY.csv")))

m$i$rts <- m$i$rts[ , .( ccy= as.factor( ccy), tms= TMS, bnch_vwap= VWAP, bnch_twap= MEANPX, vl= VOLUME)]
m$i$rts[ , tms:= fastPOSIXct( tms),]
setkey( m$i$rts, ccy, tms)

m$i$trds <- fread( "sample_trades.txt", stringsAsFactors= TRUE )
setnames( m$i$trds, c( "id", "trd_dt", "vl_dt", "tms", "ccy", "fnd", "fnd_mngr", "cprt", 
                       "cprt_prnt", "drctn", "bs_amt", "usd_vl", "rt", "prd"))

m$i$trds[ , drctn := factor( ifelse( drctn== 1, "buy", "sell")), ]

m$i$trds[ , trd_dt:= fastPOSIXct( trd_dt),]
m$i$trds[ , vl_dt:= fastPOSIXct( vl_dt),]
m$i$trds[ , tms:= fastPOSIXct( tms),]

setkey( m$i$trds, ccy, tms)
#--------------------

cst_bp <- function( drct= "buy", fxd_amt= 1e6, vrbl_amt= 1.240e6, bnch_rt= 1.25){
  10000 * ifelse( drct== "buy", 
                  1- vrbl_amt/ ( bnch_rt * fxd_amt),
                  vrbl_amt/ ( bnch_rt * fxd_amt)- 1)
}

cst_bp2 <- function( drct= "buy", rt= 1.24, bnch_rt= 1.25){
  10000 * ifelse( drct== "buy", 
                  1- rt/ bnch_rt,
                  rt/ bnch_rt- 1)
}

abs_cst <- function( drct= "buy", rt= 1.24, bnch_rt= 1.25, usd_vl= 1e6){
  ifelse( drct== "buy", 
          usd_vl * ( 1- rt/ bnch_rt),
          usd_vl * (rt/ bnch_rt- 1))
}

m$x$trds <- m$i$trds
m$x$rts <- m$i$rts
# Benchmark trades
# Rolling join to rates to get benchmark from benchmarks (then remove rows where benchmark not found)
m$y$trds <- m$x$rts[ m$x$trds[ prd== 'Spot'], roll= TRUE][ !is.na( bnch_vwap)]
# calculate cost for each benchmark
m$y$trds[ , cst_vwap := cst_bp( drct= drctn, fxd_amt= bs_amt, 
                                vrbl_amt= bs_amt * rt, bnch_rt = bnch_vwap), ]
m$y$trds[ , cst_vwap2 := cst_bp2( drct= drctn, rt= rt, bnch_rt = bnch_vwap), ]
m$y$trds[ , cst_vwap3 := abs_cst( drct= drctn, rt= rt, bnch_rt = bnch_vwap, usd_vl= usd_vl), ]

m$y$trds[ , cst_twap := cst_bp( drct= drctn, fxd_amt= bs_amt, 
                                vrbl_amt= bs_amt * rt, bnch_rt = bnch_twap), ]
m$y$trds[ , rndm := runif( n= dim( m$y$trds)[ 1], min= 0.8, max= 1.2), ]
m$y$trds[ , trd_dt := factor( as.Date( tms)), ]
m$y$trds[ , trd_hr := factor( hour( tms)),]

m$y$trds[ , c( "cst_vl", "bnch_vl") := .( usd_vl, usd_vl),]

# Identify different dimensions in the data and store these to drive the UI
m$p$ui$dims <- sapply( X= names( m$y$trds)[ which( m$y$trds[ , lapply( .SD, class)== "factor", ])], # fields which are factors
        FUN= function( x) { 
          t <- m$y$trds[ , unique( get( x)),]
          u <- paste( x, "== \"", t, "\"", sep= '')
          names( u) <- t
          return( u)}) # the levels for those factors

####### FX Benchmark ##### Get data for FX Benchmark page
getMkt <- as.data.table(fread('C:\\stuff2\\Dropbox\\Public\\work\\doc\\asif\\TCA\\Shiny_V2\\fx mkt.csv', sep=','))

getBM <- as.data.table(fread('C:\\stuff2\\Dropbox\\Public\\work\\doc\\asif\\TCA\\Shiny_V2\\fx bm2.csv', sep=','))

getBMdyn <- as.data.table(fread('C:\\stuff2\\Dropbox\\Public\\work\\doc\\asif\\TCA\\Shiny_V2\\fx bm.csv', sep=','))

getFunds <- as.data.table(fread('C:\\stuff2\\Dropbox\\Public\\work\\doc\\asif\\TCA\\Shiny_V2\\funds.csv', sep=','))

getMkt[, tms := as.POSIXct(date_)]
getMkt[, dt := as.Date(tms)]
setkey(getMkt, tms)


getBMdyn[, trade_tms := as.POSIXct(trade_tms)]
getBMdyn[, dt := as.Date(trade_tms)]
setkey(getBMdyn, trade_tms, id)

getBM[, tms := as.POSIXct(tms)]
getBM[, dt := as.Date(tms)]
setkey(getBM, tms, interval)

getFunds[, trade_tms := as.POSIXct(trade_tms)]
getFunds[, dt := as.Date(trade_tms)]
setkey(getFunds, trade_fund_manager, trade_tms, ccy_pair_desc)
