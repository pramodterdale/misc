
# This is the server logic for a Shiny web application.
# You can find out more about building applications with Shiny here:
#
# http://shiny.rstudio.com
#

library( shiny)

options(shiny.maxRequestSize=100*1024^2) 

# Wrap facet labels
wrap_facet_label <- function( labels) {
  labels <- label_value(labels, multi_line = multi_line)
  lapply(labels, function(x) {
    x <- strwrap(x, width = width, simplify = FALSE)
    vapply(x, paste, character(1), collapse = "\n")
  })}
  
# given a list of filters, combines them into an expression which when evaluated will return a logical vector that can be used to filter the data
fltr_exprsn <- function( x, exclude= ""){
  text <- paste( unlist( x[ ! names(x) %in% exclude]), 
                      collapse= " & ")
  if( text== "")
    return( parse( text= TRUE))
  else
    return( parse( text= text))
}

shinyServer( function( input, output, session) {
  
  m$p$ui <- reactiveValues( bnchmk= "vwap", 
                            dims= sapply( X= names( m$y$trds)[ which( m$y$trds[ , lapply( .SD, class)== "factor", ])], # fields which are factors
                                          FUN= function( x) { 
                                            t <- m$y$trds[ , unique( get( x)),]
                                            u <- paste( x, "== \"", t, "\"", sep= '')
                                            names( u) <- t
                                            return( u)}), # the levels for those factors
                            fltrs= TRUE,
                            title= NULL,
                            smry_tbl= list( page_length= 5, rows= 1:5))
  
  m$o$plt <- reactiveValues( cst= NULL, heatmap= NULL)
  
  observe( { 
    print( 'm$p$ui$title')
    m$p$ui$title <- paste( "Average cost of ", dim( m$o$trds())[ 1], " trades using ", m$p$ui$bnchmk, " benchmark",
                           ifelse( !is.null( m$p$brkdwn()), paste( " by", m$p$brkdwn()), ""), sep= "")
  })
  # 
  # observe( { # use observe, rather than observeEvent, because datatable doesn't seem to generate events
  #   print( 'm$p$ui$smry_tbl')
  #   m$p$ui$smry_tbl$rows <- input$smry_tbl_rows_current
  #   #m$p$ui$smry_tbl$page_length <- input$trds_tbl_state$length
  # })
  
  observeEvent( input$heatmap_click, {
    print( 'input$heatmap_click')
    
    click <- input$heatmap_click
    x <- input$heatmap_click$mapping$x
    y <- input$heatmap_click$mapping$y
    x_vl <- round( input$heatmap_click$x, 0)
    # need to reverse back y
    y_vl <- ceiling( input$heatmap_click$domain$top) - round( input$heatmap_click$y, 0)
    fct1 <- input$heatmap_click$mapping$panelvar1
    fct1_vl <- input$heatmap_click$panelvar1
    
    table <- m$o$trd_smry()
    
    if( dim( table)[ 1]== 1){
      m$p$ui$smry_tbl$rows <- 1
      return()}
    
    # select the rows
    if( is.null( fct1) & x!= "1" & y != "1"){
      print( table[ , .( as.numeric( get( y)), y_vl, 
                      as.numeric( get( x)), x_vl), ])
      row <- which( table[ , as.numeric( get( y)) == y_vl & 
                              as.numeric( get( x)) == x_vl, ])}
    
    if( is.null( fct1) & x != "1" & y == "1")
      row <- which( table[ , as.numeric( get( x)) == x_vl, ])
    
    if( is.null( fct1) & x == "1" & y != "1")
      row <- which( table[ , as.numeric( get( y)) == y_vl, ])
    
    if( !is.null( fct1))
      row <- which( table[ , as.numeric( get( y)) == y_vl & 
                              as.numeric( get( x)) == x_vl &
                              as.numeric( get( fct1)) == fct1_vl, ])
    
    if( length( row)== 0)
      return()
    
    if( row %in% m$p$ui$smry_tbl$rows)
      m$p$ui$smry_tbl$rows <- setdiff( m$p$ui$smry_tbl$rows, row)
    else
      m$p$ui$smry_tbl$rows <- sort( c( row, m$p$ui$smry_tbl$rows))
  })
  
  observeEvent( input$heatmap_brush, {
    print( 'input$heatmap_brush')
    #brush <- input$heatmap_brush
    x <- input$heatmap_brush$mapping$x
    y <- input$heatmap_brush$mapping$y
    xmin <- input$heatmap_brush$xmin
    xmax <- input$heatmap_brush$xmax
    # need to reverse back y
    ymin <- ceiling( input$heatmap_brush$domain$top) - input$heatmap_brush$ymax 
    ymax <- ceiling( input$heatmap_brush$domain$top) - input$heatmap_brush$ymin
    fct1 <- input$heatmap_brush$mapping$panelvar1
    fct1_vl <- input$heatmap_brush$panelvar1
    
    bnchmk <- paste( "cst_", m$p$ui$bnchmk, sep= '')
    table <- m$o$trd_smry()
    
    if( dim( table)[ 1]== 1){
      m$p$ui$smry_tbl$rows <- 1
      return()}
    
    # select the rows
    if( is.null( fct1) & x!= "1" & y != "1"){
      rows <- which( table[ , as.numeric( get( y)) > ymin & as.numeric( get( y)) < ymax & 
                              as.numeric( get( x)) > xmin & as.numeric( get( x)) < xmax, ])}
    
    if( is.null( fct1) & x != "1" & y == "1")
      rows <- which( table[ , as.numeric( get( x)) > xmin & as.numeric( get( x)) < xmax, ])
    
    if( is.null( fct1) & x == "1" & y != "1")
      rows <- which( table[ , as.numeric( get( y)) > ymin & as.numeric( get( y)) < ymax, ])
    
    if( !is.null( fct1))
      rows <- which( table[ , as.numeric( get( y)) > ymin & as.numeric( get( y)) < ymax &
                              as.numeric( get( x)) > xmin & as.numeric( get( x)) < xmax &
                              as.numeric( get( fct1)) == fct1_vl, ])
    
    m$p$ui$smry_tbl$rows <- rows
  })
  
  m$p$ui$zoom <- reactiveValues( x = NULL, y = NULL)
  
  observe( {   
    # Update dims to reflect selections available
    m$p$ui$dims <- sapply( X= names( m$p$ui$dims), # fields which are factors
                           FUN= function( x) { 
                             t <- m$y$trds[ eval( fltr_exprsn( m$p$ui$fltrs, exclude= x)), unique( get( x)),]
                             u <- paste( x, "== \"", t, "\"", sep= '')
                             names( u) <- t
                             return( u)}) 
    })
  
  observeEvent( input$fltrs, {
    # Update selections input:
    # 1. make the choices available reflect the chosen filters
    # 2. change the selections to only include those of the chosen filters and in that order
    slcts <- input$fltr_slcts
    i <- unlist( m$p$ui$dims[ input$fltrs]) %in% slcts  #remove selections not in the chosen filters
    slcts <- unlist( m$p$ui$dims[ input$fltrs])[ i]  #reorder selections in the chosen filters order
    updateSelectizeInput( session= session, inputId= "fltr_slcts",
                          choices= m$p$ui$dims[ rev( input$fltrs)], selected= slcts)
    
    if( length( input$fltrs)== 0)
      m$p$ui$fltrs <- TRUE
  })

  output$upld_trds_tbl <- DT::renderDataTable( {
    req( input$trd_fl$datapath)
    datatable( fread( input= input$trd_fl$datapath, stringsAsFactors= TRUE),
      options = list( lengthChange= TRUE, pageLength= 5, stateSave = TRUE),
               class = "nowrap row-border")
  })
  
  observeEvent( input$fltr_slcts, {
    # construct an expression based on the filter selections, which will return a logical when evaluated
    m$p$ui$fltrs <-  
      sapply( X= input$fltrs,
              FUN= function( x){
                t <- grep( pattern= paste( "^", x, "==", sep= ""), 
                           x= input$fltr_slcts, value= TRUE)
                if( length( t)== 0)
                  return( NULL)
                paste( "(", paste( t, collapse= " | "), ")", sep= '')}
      )
    #if( length( input$fltr_slcts)== 0)
     # m$p$ui$fltrs <- TRUE
  })
  
  observeEvent( input$bnchmk, m$p$ui$bnchmk <- input$bnchmk)
  
  observeEvent( input$cost_plot_dbl_click, {
    brush <- input$cost_plot_brush
    if (!is.null(brush)) {
      m$p$ui$zoom$x <- c(brush$xmin, brush$xmax)
      m$p$ui$zoom$y <- c(brush$ymin, brush$ymax)
      
    } else {
      m$p$ui$zoom$x <- NULL
      m$p$ui$zoom$y <- NULL
    }})
  
  observeEvent( input$cost_plot_brush, {
    print( 'input$cost_plot_brush')
    brush <- input$cost_plot_brush
    bnchmk <- paste( "cst_", m$p$ui$bnchmk, sep= '')
    

    # select the rows
    if( is.null( brush$mapping$panelvar1) )
      rows <- which( m$o$trds()[ , get( brush$mapping$y) > brush$ymin & get( brush$mapping$y) < brush$ymax &
                                 get( brush$mapping$x) > brush$xmin & get( brush$mapping$x) < brush$xmax, ])
    else
      rows <- which( m$o$trds()[ , get( brush$mapping$y) > brush$ymin & get( brush$mapping$y) < brush$ymax &
                                   get( brush$mapping$x) > brush$xmin & get( brush$mapping$x) < brush$xmax &
                                   get( brush$mapping$panelvar1) == brush$panelvar1, ])
   
    table= dataTableProxy( "trds_tbl")
    clearSearch( proxy= table)
    selectPage( proxy= table, page= ceiling( min( rows) / input$trds_tbl_state$length))
    selectRows( proxy= table, selected= rows)
  })
  
  observeEvent( input$cost_plot_click, {
    points <- nearPoints( df= m$o$trds(), allRows= TRUE,
                               coordinfo= input$cost_plot_click, yvar= "y", xvar= "x",
                               threshold = 5, maxpoints = 1, addDist = TRUE)
    table <- dataTableProxy( "trds_tbl")
    row <- which( points$selected_)
    clearSearch( proxy= table)
    selectPage( proxy= table, page= ceiling( row / input$trds_tbl_state$length))
    selectRows( proxy= table, selected= row)
    })
  
  m$p$brkdwn <- reactive({
    input$brkdwn})

  m$o$trd_smry <- reactive({
    print( 'm$o$trd_smry')
    grp_by <- NULL
    if( !is.null( m$p$brkdwn())){
      grp_by <- c( grp_by, m$p$brkdwn())}
    
    fnc <- input$smry_fnc
    bnchmk <- paste( "cst_", m$p$ui$bnchmk, sep= '')
    fnc <- parse( text= paste( fnc, "( ", bnchmk, ")", sep= ""))
    
    print( fnc)
    # Apply filters
    t <- m$y$trds[ eval( fltr_exprsn( m$p$ui$fltrs)), 
              .( mtrc= eval( fnc), n= .N), 
              by= grp_by]
   
    print( t)
    
    # Re-order factors, serves two purposes:
    # 1. Orders display in heatmap: highest values top left in heatmap
    # 2. Allows the brushing to work to select for the trades level plot and table
    for( g in grp_by){
      updt_expr <- parse( text= paste( 
        g, ' := factor( x= ', g, ', levels= ', 
        't[ , .( mtrc= sum( mtrc * n)/ sum( n)),', g, ',]',
        '[ order( mtrc, decreasing= TRUE), ', g, ',])', sep= ''))
      t[ , eval( updt_expr),]}
    
    # setting the key serves two purposes
    # 1. It stores the UI breakdowns
    # 2. Allows the join to the trades table to limit the trades shown in the trade plot & table
    setkeyv( t, rev( grp_by))
    
    # Create an additional factor for ordering the display of the facets in the trade plot
    if( !is.null( grp_by))
      t[ , eval( parse( text= paste( 
      'facet_by := factor( x= paste( ', 
      paste( grp_by, collapse= ','), 
      ', sep= " - "), levels= paste( ', 
      paste( grp_by, collapse= ','), 
      ', sep= " - "))', sep= ""))),]
    else
      t[ , facet_by:= 1,]
    
    print( t)
    
    isolate({ #isolate needed to stop this function being recalled when m$p$ui$smry_tbl$rows changes elsewhere
    if( is.null( grp_by))
      m$p$ui$smry_tbl$rows <- 1
    if( length( grp_by) == 1)
      m$p$ui$smry_tbl$rows <- 1: min( dim( t)[ 1], 5)
    if( length( grp_by) > 1)
      m$p$ui$smry_tbl$rows <- which( t[ , get( grp_by[ 2]) == levels( get( grp_by[ 2]))[ 1],])})
    
    return( t)
  })
  
  m$o$trds <- reactive({
    print( 'm$o$trds')
    req( m$p$ui$smry_tbl$rows)
    # construct the benchmark variable
    bnchmk <- paste( "cst_", m$p$ui$bnchmk, sep= '')
    if( is.null( m$p$brkdwn()))
      t <- m$y$trds[ eval( fltr_exprsn( m$p$ui$fltrs)), ,][ 
        # sort the data to ensure that is appears in the same order in the table at the bottom of the UI as in the graph
        order( -get( bnchmk), rndm),,]
    else
      t <- m$y$trds[ eval( fltr_exprsn( m$p$ui$fltrs)), ,][ 
        # sort the data to ensure that is appears in the same order in the table at the bottom of the UI as in the graph
        order( get( m$p$brkdwn()), -get( bnchmk), rndm) ]
    
    u <- m$o$trd_smry()[ m$p$ui$smry_tbl$rows]
    setkeyv( t, key( u))
    
    #u[ , facet_by:= .I, ]
    
    if( !is.null( key( t)))
      t <- t[ u, nomatch= 0]
    else
      t[ , facet_by:= 1, ]
    setkeyv( t, key( u))
    
    # Set x and y for plotting 
    
    t[ , c( "y", "n") := .( get( bnchmk), n= .N), 
      .( facet_by, brk= cut( get( bnchmk), breaks= 100))]
    t[ , x := runif( n= .N, min= -n/ max( n), max= n/ max( n)), .( facet_by)]
    # For volume accumulate volume
    if( bnchmk== "cst_vl"){
      t[ order( y), 
         c( "y", "x") := .( cumsum( y), runif( n= .N, min= -1, max= + 1)), facet_by]
      }
    
    
    return( t)
  })
  
  output$title <- renderText( m$p$ui$title)
  
  output$heatmap <- renderPlot( {
    print( 'output$heatmap')
    data <- m$o$trd_smry()
    
    if( is.null( key( data))){
      x <- "1"
      y <- "1"}
    if( length( key( data))== 1){
      x <- key( data)[ 1]
      y <- "1"}
    if( length( key( data))== 2){
      x <- key( data)[ 2]
      y <- key( data)[ 1]}
    
    p <- ggplot( data= data, mapping= aes_string( x= x, y= y, fill= "mtrc")) +
      geom_tile() +
      geom_tile( data= function( x) x[ m$p$ui$smry_tbl$rows], colour= m$p$cl$bl1, 
                 size= 1, fill= m$p$cl$bl1, alpha= I(.05)) +
      geom_text( mapping= aes( label= round( mtrc, 1), 
                               colour= cut( abs( mtrc), 2, labels= 1:2))) +
      scale_x_discrete( position = "top") + 
      scale_colour_manual( values= c( "1"= "black", "2"= "white")) +
      blank_theme() 
    
    if( length( key( data))== 2) 
      p <- p + theme( axis.text.x= element_text( angle= 45, hjust = 0, size = rel(1)),
                      axis.text.y= element_text( hjust = 1, size = rel(1)),
                      strip.text = element_text( size = rel(1)))
    else
      p <- p + theme( axis.text.x= element_text( angle= 45, hjust = 0, size = rel(1)),
                      strip.text = element_text( size = rel(1)))
    
    if( length( key( data))>= 2)
      p <- p + scale_y_discrete( 
        limits= data[ , rev( levels( get( key( data)[ 1]))),])
    
    if( data[ , .N, ]== 1)
      p <- p + scale_colour_manual( values= "white") +
      scale_fill_gradient2( limits= c( data[ , min( 0, mtrc), ],
                                                  data[ , max( 0, mtrc), ]),
                                      low = m$p$cl$grn1, mid = "white", high= m$p$cl$rd,
                                      midpoint = 0,  space = "Lab", na.value = "grey50")
    else
      p <- p + scale_fill_gradient2( limits= c( ),
                              low = m$p$cl$grn1, mid = "white", high= m$p$cl$rd,
                              midpoint = 0,  space = "Lab", na.value = "grey50")
    m$o$plt$heatmap <- p
    
    return( m$o$plt$heatmap)
  },
  width= function() {
    key <- key( m$o$trd_smry())
    
    if( is.null( key))
      return( 160)
    if( length( key)== 1)
      ncols <- m$o$trd_smry()[ , .N, get( key[ 1])][ , .N,]
    if( length( key)== 2)
      ncols <- m$o$trd_smry()[ , .N, get( key[ 2])][ , .N,]
    
    row_hdng_spc <- ifelse( is.na( key[ 2]), 0,
                            m$o$trd_smry()[ , 4 * max( nchar( levels( get( key[ 2])))), ])
    return( max( 640, row_hdng_spc + 40 * ncols))}, 
  
  height= function() {
    key <- key( m$o$trd_smry())
    
    if( is.null( key))
      return( 60)
    col_hdng_spc <- m$o$trd_smry()[ , 4 * max( nchar( levels( get( key[ 1])))), ]
    if( length( key)== 1)
      nrows <- 1
    if( length( key)== 2)
      nrows <- m$o$trd_smry()[ , .N, get( key[ 1])][ , .N, ]
     
    if( nrows <= 1)
      return( col_hdng_spc + 60)
    else
      return( max( 320, col_hdng_spc + 20 * nrows))})
  
  output$cost_plot <- renderPlot({
    print( 'output$cost_plot')
    req( m$p$ui$smry_tbl$rows)
    #facet_by <- parse( text= paste( "list( facet_by= .I, ", 
    #                                paste( names( m$o$trd_smry()), collapse= ","), ")"))
    bnch <- paste( "cst_", m$p$ui$bnchmk, sep= '')
   
    trds <- m$o$trds()
    
    # m$y$trds[ , .( cst_vwap, n= .N), .( brk= cut( cst_vwap, breaks= 100))][ 
    #   , .( brk, cst_vwap, rndm= -.5 + runif( n= .N, min= -n/ max( n), max= n/ max( n))), ]
    
    #p <- ggplot( data= m$o$trds()) +
    p <- ggplot( data= trds) +
      geom_point( mapping= aes( y= y, x= x, size= usd_vl), alpha= 0.1) +
      geom_segment( data= m$o$trd_smry()[ m$p$ui$smry_tbl$rows],
                                          #eval( facet_by)],
                    mapping= aes( y= mtrc, yend= mtrc, x= -1, xend= 1,
                                  colour= I( ifelse( mtrc> 0, m$p$cl$rd, 
                                                     m$p$cl$grn1))),
                    size= 1, alpha= 0.8) +
      # geom_rect( data= m$o$trd_smry()[ m$p$ui$smry_tbl$rows,
      #                                  eval( facet_by)],
      #            mapping= aes( ymax= ifelse( mtrc> 0, mtrc, 0), 
      #                          ymin= ifelse( mtrc< 0, mtrc, 0), 
      #                          xmin= .75, xmax= 1.25),
      #            colour= m$p$cl$bl1, size= 1, alpha= 0) +
      # geom_point( mapping= aes_string( y= paste( "cst_", m$p$ui$bnchmk, sep= ''), 
      #                           x= "rndm", size= "usd_vl"), alpha= 0.1) +
      scale_x_continuous( limits= c( -1.00, 2)) +
      geom_text( m$o$trd_smry()[ m$p$ui$smry_tbl$rows],
                                 #eval( facet_by)],
                 mapping= aes( y= mtrc, 
                               x= 1.1, label= round( mtrc, 1),
                               colour= I( ifelse( mtrc> 0, m$p$cl$rd, 
                                                  m$p$cl$grn1))),
                               fontface= "bold", size= 5, hjust= 0) +
      blank_theme() +
      theme( panel.grid.major.y = element_line( colour= 'grey'),
             axis.text.y= element_text( colour= 'black', size = rel(1)),
             strip.text = element_text( size = rel(1)),
             strip.background= element_rect(fill= NA, colour= m$p$cl$bl1, size= 1))
    
    if( m$o$trd_smry()[ , .N, ]> 1)
      p <- p + facet_wrap( facets= "facet_by", ncol= 8,
                           labeller= label_wrap_gen( width= 16))

    # Zoom in as necessary
    m$o$plt$cst <- p + coord_cartesian( xlim = m$p$ui$zoom$x, ylim = m$p$ui$zoom$y) 
    
    return( m$o$plt$cst)
  }, 
  width= function() {
    req( m$p$ui$smry_tbl$rows)
    if( m$o$trd_smry()[ m$p$ui$smry_tbl$rows, .N, ]== 1)
      return( 240)
    if( m$o$trd_smry()[ m$p$ui$smry_tbl$rows, .N, ]>= 10)
      return( 120 * 10)
    return( 120 * m$o$trd_smry()[ m$p$ui$smry_tbl$rows, .N, ])}, 
  height= function() { 
    if( m$o$trd_smry()[ m$p$ui$smry_tbl$rows, .N, ]<= 10)
      return( 320)
    return( 320 * ceiling( m$o$trd_smry()[ m$p$ui$smry_tbl$rows, .N, ]/ 10))})
  
  output$trds_tbl <- DT::renderDataTable( {
    datatable( data= m$o$trds()[ , lapply( .SD, FUN= function( x) substr( x, 1, 20)), 
                .SDcols= is.character( names( m$o$trds()))],
               extensions= c( 'Buttons', 'ColReorder'), 
               options = list( lengthChange= TRUE, lengthMenu = c(5, 10, 20, 40),
                               pageLength= 5, stateSave = TRUE, colReorder = TRUE,
                               dom = 'Blfrtip', buttons = c( 'copy', 'csv', 'excel', I('colvis'))),
               class = "nowrap row-border")
    })
  
  output$smry_info <- renderUI({ NULL })
    
  output$trade_info <- renderUI({
    hover <- input$cost_plot_hover
    hover_point <- nearPoints( df= m$o$trds(), 
                       coordinfo= hover, yvar= "y", xvar= "x",
                       threshold = 5, maxpoints = 1, addDist = TRUE)
  
    # calculate point position INSIDE the image as percent of total dimensions
    # from left (horizontal) and from top (vertical)
    left_pct <- (hover$x - hover$domain$left) / (hover$domain$right - hover$domain$left)
    top_pct <- (hover$domain$top - hover$y) / (hover$domain$top - hover$domain$bottom)
  
    # calculate distance from left and bottom side of the picture in pixels
    left_px <- hover$range$left + left_pct * (hover$range$right - hover$range$left)
    top_px <- hover$range$top + top_pct * (hover$range$bottom - hover$range$top)
  
    # create style property for tooltip
    # background color is set so tooltip is a bit transparent
    # z-index is set so we are sure are tooltip will be on top
    style <- paste0( "position:absolute; z-index:100; background-color: rgba(245, 245, 245, 0.85); ",
                  "left:", left_px + 2, "px; top:", top_px + 2, "px;")
    
    # actual tooltip created as wellPanel
    
    if( nrow( hover_point)== 0)
      return( NULL)
    else
      wellPanel(
        style = style,
        p(HTML(paste0( "<b> Cost: </b>", round( hover_point[[ paste( "cst_", m$p$ui$bnchmk, sep= '')]], 1), "BP <br/>",
                     "<b> click for more details <br/>", 
                     "<b> drag to select more trades <br/>"))))
    })
  
  output$click_info <- renderUI({
    click <- input$cost_plot_click
    point <- nearPoints( df= m$o$trds(), coordinfo= click, xvar= "x", yvar= "y",
                         threshold = 5, maxpoints = 1, addDist = TRUE)
    
    if (nrow(point) == 0) return( NULL)
    
    # calculate point position INSIDE the image as percent of total dimensions
    # from left (horizontal) and from top (vertical)
    left_pct <- (click$x - click$domain$left) / (click$domain$right - click$domain$left)
    top_pct <- (click$domain$top - click$y) / (click$domain$top - click$domain$bottom)
    
    # calculate distance from left and bottom side of the picture in pixels
    left_px <- click$range$left + left_pct * (click$range$right - click$range$left)
    top_px <- click$range$top + top_pct * (click$range$bottom - click$range$top)
    
    # create style property fot tooltip
    # background color is set so tooltip is a bit transparent
    # z-index is set so we are sure are tooltip will be on top
    style <- paste0("position:absolute; z-index:100; background-color: rgba(245, 245, 245, 0.85); ",
                    "left:", left_px + 2, "px; top:", top_px + 2, "px;")
    
    output$trds_tbl2 <- DT::renderDataTable({ point})
    
    # actual tooltip created as wellPanel
    wellPanel(
      style = style,
      DT::dataTableOutput( 'trds_tbl2'))})
  
  output$sv_rpt <- downloadHandler(
    filename = function() {
      'TCA report.pdf'
    },
    content = function( file) {
      src <- normalizePath('TCA_report.Rmd')
      
      ## temporarily switch to the temp dir, in case you do not have write
      ## permission to the current working directory
      owd <- setwd( tempdir())
      on.exit( setwd( owd))
      file.copy(src, 'TCA_report.Rmd', overwrite = TRUE)
      
      library(rmarkdown)
      out <- render('TCA_report.Rmd', pdf_document())
      file.rename(out, file)
    })
  
  
  ####### FX Benchmark page ########
  
  # *********** CLS Benchmark **************
  mkt <- reactive({getMkt[dt==input$date, .(tms, Mkt = xr)]})
  gmkt <-reactive({melt(mkt(),'tms')[variable %in% input$bm]})
  
  bm <- reactive({getBM[dt == input$date & interval == input$intv, .(tms, vwap, twap)]})
  bm_cls <- reactive({melt(bm(),'tms')[variable %in% input$bm]})
  
  bm_dyn <- reactive({getBMdyn[dt == input$date, .(tms = trade_tms, vwap_dyn, twap_dyn)]})
  bm_dyncls <- reactive({melt(bm_dyn(),'tms')[variable %in% input$bm]})
  
  mini <- reactive({rbind(bm_cls()[value == bm_cls()[, (value = min(value))]],
                          bm_dyncls()[value == bm_dyncls()[, (value = min(value))]])})

  min2 <- reactive({mini()[value == mini()[,.(value = min(value))]]})

  maxi <- reactive({rbind(bm_cls()[value == bm_cls()[, (value = max(value))]],
                          bm_dyncls()[value == bm_dyncls()[, (value = max(value))]])})

  max2 <- reactive({maxi()[value == maxi()[,.(value = max(value))]]})

  # ******** Fund data **************
  bm_fnd <- reactive({getFunds[dt == input$date]})
  observe({updateSelectInput(session, "fund", choices = unique(as.character(bm_fnd()[,trade_fund_manager])) )})
  
  bm_trd <- reactive({
    if (input$inclFnd){
      bm_fnd()[trade_fund_manager == input$fund, .(tms = as.POSIXct(trade_tms), exchange_rate, trade_val, Action_)]
    } else {
      bm_fnd()[trade_fund_manager == "",.(tms = as.POSIXct(trade_tms), exchange_rate, trade_val, Action_)]
    }
  })
  
  # ********** Output **************
  fxbm_ranges <- reactiveValues(x=NULL, y=NULL)
  
  #output$bm_plot 
  output$fxbm <- renderPlot({
    ggplot() +
      geom_line(data = gmkt(), aes(x=tms, y = value, color=variable)) +
      geom_line(data = bm_cls(), aes(x=tms, y = value, color=variable)) +
      geom_line(data = bm_dyncls(), aes(x=tms, y = value, color=variable)) +
      geom_errorbarh(data = min2(), aes(x=tms, y= value, xmin= tms-60*7, xmax= tms+60*7), height = 0, size = 1, color = "red") +
      geom_errorbarh(data = max2(), aes(x=tms, y= value, xmin= tms-60*7, xmax= tms+60*7), height = 0, size = 1, color = "red") +
      geom_point(data = bm_trd(), aes(x = tms, y= exchange_rate, size = trade_val, color = Action_), alpha = 0.4) +
      scale_x_datetime(limits = c(fxbm_ranges$xmin, fxbm_ranges$xmax)) +
      scale_y_continuous(limits = c(fxbm_ranges$ymin, fxbm_ranges$ymax)) +
      theme(axis.text= element_text( size= 12), axis.title.x = element_blank(), axis.title.y = element_blank(),
            panel.grid.minor = element_line(colour="grey60", linetype="dotted"),
            panel.grid.major = element_line(colour="grey60", linetype="dotted"),
            panel.background = element_blank())
  })

  #zoom in brush section and double click. Double click on nonbrush section will return to normal
  observeEvent(input$fxbm_plot_dbl_click, {
    fxbm_brush <- input$fxbm_plot_brush
    if (!is.null(fxbm_brush)){
      fxbm_ranges$xmin <- as.POSIXct(fxbm_brush$xmin, origin="1970-01-01")
      fxbm_ranges$xmax <- as.POSIXct(fxbm_brush$xmax, origin="1970-01-01")
      fxbm_ranges$ymin <- fxbm_brush$ymin
      fxbm_ranges$ymax <- fxbm_brush$ymax
    }
    else{
      fxbm_ranges$xmin <- NULL
      fxbm_ranges$xmax <- NULL
      fxbm_ranges$ymin <- NULL
      fxbm_ranges$ymax <- NULL
    }
  })
  
  #brush section will select trades from table
  observeEvent( input$fxbm_plot_brush, {
    fxbm_brush_trd <- input$fxbm_plot_brush
    #get row ids
    rows <- bm_trd()[tms >= as.POSIXct(fxbm_brush_trd$xmin, origin="1970-01-01") & tms <= as.POSIXct(fxbm_brush_trd$xmax, origin="1970-01-01") &
                     exchange_rate >= fxbm_brush_trd$ymin & exchange_rate <= fxbm_brush_trd$ymax, which=TRUE]
    
    table= dataTableProxy( "fxbm_trds_tbl")
    clearSearch(proxy= table)
    selectPage(proxy= table, page= ceiling(min(rows)/input$fxbm_trds_tbl_state$length)) #find earliest record page number
    selectRows(proxy= table, selected = rows) #highlight records in table
    
  })

  #single click to select trades and reset table if nothing is clicked
  observeEvent( input$fxbm_plot_click, {
    if (nrow(bm_trd()) > 0){
      points <- nearPoints( df= bm_trd(), allRows= TRUE, coordinfo= input$fxbm_plot_click,
                            yvar= "exchange_rate", xvar= "tms", threshold = 5, maxpoints = 1)

      table <- dataTableProxy( "fxbm_trds_tbl")
      row <- which( points$selected_)
      clearSearch( proxy= table)
      selectPage( proxy= table, page= ceiling( row / input$fxbm_trds_tbl_state$length))
      selectRows( proxy= table, selected = row)
    }
  })
  
  #output panel for hover details
  
  output$fxbm_info <- renderUI({
    hover <- input$fxbm_plot_hover
    
    if (nrow(bm_trd()) == 0) return(NULL)
    
    points <- nearPoints( df= bm_trd(), coordinfo= hover,
                        yvar= "exchange_rate", xvar= "tms", threshold = 5, maxpoints = 1, addDist = TRUE)
    
    if (nrow(points) == 0) return(NULL)
    
    left_pct <- (hover$x - hover$domain$left) / (hover$domain$right - hover$domain$left)
    top_pct <- (hover$domain$top - hover$y) / (hover$domain$top - hover$domain$bottom)
    
    left_px <- hover$range$left + left_pct * (hover$range$right - hover$range$left)
    top_px <- hover$range$top + top_pct * (hover$range$bottom - hover$range$top)
    
    style <- paste0("position:absolute; z-index:100; background-color: rgba(245, 245, 245, 0.85); ",
                    "left:", left_px + 2, "px; top:", top_px + 2, "px;")
    
    wellPanel(
      style = style,
      p(HTML(paste0("<b> Action: ", points[, Action_], ", </b>",
                    "<b> XR: ", round(points[, exchange_rate], 5), ", </b>",
                    "<b> Volume: ", round(points[, trade_val], 0), " </b>")
             ))
    )
  })
  
  #trades detail
  output$fxbm_trds_tbl <- DT::renderDataTable({
    datatable( data= bm_trd(),
               extensions= c( 'Buttons', 'ColReorder'),
               options = list( lengthChange= TRUE, lengthMenu = c(5, 10, 20, 50),
                             pageLength= 10, stateSave = TRUE, colReorder = TRUE,
                             dom = 'Blfrtip', buttons = c( 'copy', I('colvis'))),
             class = "nowrap row-border")
  })
})