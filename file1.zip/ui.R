library( shiny)
library( ggplot2)
library( data.table)
library( markdown)

navbarPage(
  title= div(img(src="CLS_logo.png", height="32", width="84"), "TCA"),
  tabPanel(
    "Summary",
    fluidPage( 
      titlePanel("Hello TCA"), 
      fluidRow( column(4, plotOutput( "ovw_intraday_plot"))))),
  tabPanel(
    "Trade level analysis",
    fluidPage( 
      column(
        width= 3,
        wellPanel(
          selectInput( inputId= 'bnchmk', label= 'Benchmark', 
                       choices= substr( grep( "cst_", names( m$y$trds), value= TRUE), 
                                        start= 5, stop= 99999)),
                       
          selectInput( inputId= 'smry_fnc', label= 'Summarise as', 
                       choices= c(  `average`= "mean", `median`= "median", `total`= "sum" )),
                                    
          selectizeInput( inputId= 'brkdwn', label= 'Breakdown by', multiple= TRUE,
                          options = list( maxItems= 2), 
                          choices= names( m$p$ui$dims)),
          
          selectizeInput( inputId= 'fltrs', label= 'Filters', multiple= TRUE,
                          choices=names( m$p$ui$dims), selected= "fnd_mngr"),
          
          selectizeInput( inputId= 'fltr_slcts', width= 600,
                          label= 'Filter selections', multiple= TRUE,
                          choices= m$p$ui$dims$fnd_mngr, selected= m$p$ui$dims$fnd_mngr[[ 1]])),
          downloadButton( 'sv_rpt', label= "Save to PDF")),
        column( 
          width= 9, 
          fluidRow(
            h3( textOutput("title")),
            hr(),
            #div( DT::dataTableOutput( 'smry_tbl'),
            #     tags$head( tags$style( type="text/css", "#smry_tbl table td {line-height:50%;}")),
            #     style = "font-size:100%"),
            
            div( style= "position:relative",
                 plotOutput( "heatmap", height= "auto",
                             hover = hoverOpts( id= "heatmap_hover", delay= 100, 
                                           delayType = "debounce"),
                             dblclick = clickOpts( id= "heatmap_dbl_click"),
                             #click = clickOpts( id= "heatmap_click"),
                             brush= brushOpts( id= "heatmap_brush",  
                                          resetOnNew= TRUE)),
                 uiOutput("smry_info")),
            hr(),
            div( style= "position:relative", 
                 plotOutput("cost_plot", height= "auto",
                            hover = hoverOpts( id= "cost_plot_hover", delay= 100, 
                                               delayType = "debounce"),
                            dblclick = clickOpts( id= "cost_plot_dbl_click"),
                            click = clickOpts( id= "cost_plot_click"),
                            brush= brushOpts( id= "cost_plot_brush", direction= "y", 
                                              resetOnNew= FALSE)), 
                 uiOutput("trade_info")),
          hr(),
          fluidRow( 
            div( DT::dataTableOutput( 'trds_tbl'),
                 tags$head(tags$style(type="text/css", "#trds_tbl table td {line-height:50%;}")),
                 style = "font-size:75%")))))),

  tabPanel("FX Benchmark",
           fluidPage(
             column(width=3, 
                    wellPanel(
                      checkboxGroupInput("bm","Benchmark", choices = list("Mkt","vwap","twap","vwap_dyn","twap_dyn"), selected = c("twap","twap_dyn")),  
                      selectInput("cur","Currency",choices = list("EUR/USD","EUR/JPY","GBP/USD"), selected = "EUR/USD"),
                      selectInput("intv","Interval", choices = list(5,10,20,30,60), selected = 30),
                      dateInput("date","Date Input",value="2017-01-12"),
                      checkboxInput("inclFnd","Include Fund",value = FALSE),
                      selectInput("fund","Funds","")
                    )),
             column(width = 9,
                    fluidRow(div(style="position:relative",
                        plotOutput('fxbm',
                                   hover = hoverOpts( id='fxbm_plot_hover', delay=100, delayType = 'debounce'),
                                   dblclick = clickOpts( id= "fxbm_plot_dbl_click"),
                                   click = clickOpts( id= "fxbm_plot_click"),
                                   brush= brushOpts( id= "fxbm_plot_brush", direction = "xy", resetOnNew= FALSE)),
                        uiOutput('fxbm_info'))),
                    hr(),
                    h4('Trades detail'),
                    fluidRow(div( DT::dataTableOutput('fxbm_trds_tbl'),
                                  tags$head(tags$style(type="text/css", "#fxbm_trds_tbl table td {line-height:50%;}")),
                                                style = "font-size:75%"))
                    )
        )),

tabPanel( "Upload data",
         fileInput( inputId= 'trd_fl', label= 'Choose trade file to upload',
                    accept=c('text/csv', 
                            'text/comma-separated-values,text/plain', 
                            '.csv')),
         div( DT::dataTableOutput( 'upld_trds_tbl'),
              #style = "overflow:scroll; font-size:75%")
              style = "font-size:75%")
),
navbarMenu("More",
           tabPanel("Table",
                    sidebarLayout(
                      sidebarPanel(
                        radioButtons("plotType", "Plot type",
                                     c("Scatter"="p", "Line"="l")
                        )
                      ),
                      mainPanel(
                        plotOutput("plot2"))
                    )),
           tabPanel("About"
                    
           )
)
)
